﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace VividboxBlazor.Server.Migrations
{
    public partial class EditionsInit : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
